#ifndef SOUND_H
#define	SOUND_H
void play_sfx( char *name );
int sound_thread ( void *scr );
#endif
